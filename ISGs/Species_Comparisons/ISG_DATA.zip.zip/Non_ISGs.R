# Install and load required packages
if (!requireNamespace("biomaRt", quietly = TRUE)) {
  install.packages("biomaRt")
}
if (!requireNamespace("dplyr", quietly = TRUE)) {
  install.packages("dplyr")
}
library(biomaRt)
library(dplyr)

# Function to process one species
process_species <- function(species, genes, dataset, host = "https://www.ensembl.org") {
  # Check if genes vector is empty
  if (length(genes) == 0 || all(is.na(genes))) {
    cat("Error: No valid gene symbols provided for", species, "\n")
    return(NULL)
  }
  
  # Connect to BioMart
  ensembl <- tryCatch({
    mart <- useMart("ENSEMBL_MART_ENSEMBL", dataset = dataset, host = host)
    # Verify dataset exists
    datasets <- listDatasets(mart)
    if (!dataset %in% datasets$dataset) {
      cat("Error: Dataset", dataset, "not valid for", species, ". Available datasets:\n")
      print(datasets)
      return(NULL)
    }
    mart
  }, error = function(e) {
    cat("Error connecting to BioMart for", species, ":", e$message, "\n")
    return(NULL)
  })
  
  if (is.null(ensembl)) return(NULL)
  
  # Query BioMart for transcripts using gene symbols
  results <- tryCatch({
    getBM(attributes = c("ensembl_gene_id", "external_gene_name", 
                         "ensembl_transcript_id", "transcript_biotype"),
          filters = "external_gene_name",
          values = genes,
          mart = ensembl)
  }, error = function(e) {
    cat("Error querying BioMart for", species, ":", e$message, "\n")
    return(data.frame())
  })
  
  if (nrow(results) == 0) {
    cat("No results found for", species, "\n")
    return(data.frame())
  }
  
  # Summarize isoforms per gene
  summary <- results %>%
    group_by(ensembl_gene_id, external_gene_name) %>%
    summarise(
      total_isoforms = n(),
      protein_coding = sum(transcript_biotype == "protein_coding"),
      non_protein_coding = sum(transcript_biotype != "protein_coding"),
      .groups = "drop"
    ) %>%
    filter(external_gene_name %in% genes)
  
  # Save results
  output_file <- paste0(species, "_random_isoforms.csv")
  write.csv(summary, output_file, row.names = FALSE)
  cat("Processed", species, "- Results saved to", output_file, "with", nrow(summary), "genes\n")
  
  return(summary)
}

# Function to get random genes excluding input list
get_random_genes <- function(species, gene_file, dataset, host, n = 100) {
  # Check if gene file exists
  if (!file.exists(gene_file)) {
    cat("Error: File", gene_file, "not found for", species, "\n")
    return(NULL)
  }
  
  # Read input gene list
  input_genes <- tryCatch({
    readLines(gene_file)
  }, error = function(e) {
    cat("Error reading file", gene_file, "for", species, ":", e$message, "\n")
    return(NULL)
  })
  
  if (is.null(input_genes)) return(NULL)
  
  # Clean input gene list
  input_genes <- trimws(input_genes)
  input_genes <- input_genes[input_genes != ""]
  
  # Connect to BioMart
  ensembl <- tryCatch({
    useMart("ENSEMBL_MART_ENSEMBL", dataset = dataset, host = host)
  }, error = function(e) {
    cat("Error connecting to BioMart for", species, ":", e$message, "\n")
    return(NULL)
  })
  
  if (is.null(ensembl)) return(NULL)
  
  # Get only protein-coding genes
  all_genes_df <- tryCatch({
    getBM(attributes = c("external_gene_name", "transcript_biotype"),
          filters = "biotype",
          values = "protein_coding",
          mart = ensembl)
  }, error = function(e) {
    cat("Error retrieving protein-coding gene list for", species, ":", e$message, "\n")
    return(NULL)
  })
  
  if (is.null(all_genes_df) || nrow(all_genes_df) == 0) {
    cat("No protein-coding genes retrieved for", species, "\n")
    return(NULL)
  }
  
  # Get unique gene names
  all_genes <- unique(all_genes_df$external_gene_name)
  
  # Remove input genes
  available_genes <- setdiff(all_genes, input_genes)
  
  # Check if enough genes are available
  if (length(available_genes) == 0) {
    cat("Error: No genes available after excluding input list for", species, "\n")
    return(NULL)
  }
  
  # Sample random genes
  n_sample <- min(n, length(available_genes))
  if (n_sample < n) {
    cat("Warning: Only", n_sample, "genes available for", species, "after excluding input list\n")
  }
  
  set.seed(123)
  random_genes <- sample(available_genes, n_sample)
  
  return(random_genes)
}

# Define species and their gene lists
species_list <- list(
  list(species = "chicken", gene_file = "Chicken_ISGs.txt", dataset = "ggallus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "cow", gene_file = "Cow_ISGs.txt", dataset = "btaurus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "dog", gene_file = "Dog_ISGs.txt", dataset = "clfamiliaris_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "fruit_bat", gene_file = "Fruit_bat_ISGs.txt", dataset = "pvampyrus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "horse", gene_file = "Horse_ISGs.txt", dataset = "ecaballus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "human", gene_file = "Human_ISGs.txt", dataset = "hsapiens_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "microbat", gene_file = "Microbat_ISGs.txt", dataset = "mlucifugus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "pig", gene_file = "Pig_ISGs.txt", dataset = "sscrofa_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "rat", gene_file = "Rat_ISGs.txt", dataset = "rnorvegicus_gene_ensembl", host = "https://www.ensembl.org"),
  list(species = "sheep", gene_file = "Sheep_ISGs.txt", dataset = "oaries_gene_ensembl", host = "https://www.ensembl.org")
)

# Process all species
results <- lapply(species_list, function(s) {
  # Get random genes
  random_genes <- get_random_genes(s$species, s$gene_file, s$dataset, s$host, n = 100)
  if (is.null(random_genes)) return(NULL)
  
  # Process random genes
  process_species(s$species, random_genes, s$dataset, s$host)
})

# Combine results into a single data frame
combined_results <- bind_rows(results, .id = "species")
write.csv(combined_results, "all_species_random_isoforms.csv", row.names = FALSE)
cat("Combined results saved to all_species_random_isoforms.csv\n")